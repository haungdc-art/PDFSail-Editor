/**
 * DownloadButton — Commit 4 +
 *
 * 页面顶部右上角的 Download 入口：
 *   1. 点击后显示全屏进度条 overlay
 *   2. 调用 handleExport 生成 PDF（本地下载）
 *   3. 模拟"上传/准备/跳转"3 阶段进度
 *   4. 完成后跳转到 https://www.pdfsail.com/ready
 *
 * 设计权衡：
 *   - 跳转目标 www.pdfsail.com 是生产域名，跨域无法直接传文件
 *   - 因此本地先生成并下载 PDF，再跳转到 Ready 页（用户在 pdfsail.com 完成后续流程）
 *   - 进度条是模拟的（handleExport 本身是同步生成 blob，没有细粒度进度）
 */

import { useState } from "react";
import { createPortal as renderToBody } from "react-dom";

interface DownloadButtonProps {
  handleExport: (skipPay?: boolean) => Promise<void>;
  disabled?: boolean;
}

type Phase = "idle" | "preparing" | "uploading" | "redirecting" | "done";

const PHASE_LABEL: Record<Phase, string> = {
  idle: "",
  preparing: "Preparing your document…",
  uploading: "Uploading to PDFSail…",
  redirecting: "Redirecting to checkout…",
  done: "Complete!",
};

export function DownloadButton({ handleExport, disabled }: DownloadButtonProps) {
  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState(0);

  const start = async () => {
    if (disabled || phase !== "idle") return;
    setPhase("preparing");
    setProgress(5);

    // 阶段 1：生成 PDF（调用 handleExport，本地下载）
    try {
      await handleExport(true);
    } catch (e) {
      console.error("Export failed:", e);
      setPhase("idle");
      setProgress(0);
      return;
    }

    // 阶段 2：模拟上传进度
    setPhase("uploading");
    for (let p = 30; p <= 70; p += 5) {
      setProgress(p);
      await sleep(120);
    }

    // 阶段 3：跳转准备
    setPhase("redirecting");
    for (let p = 75; p <= 95; p += 5) {
      setProgress(p);
      await sleep(100);
    }

    setPhase("done");
    setProgress(100);
    await sleep(500);

    // 跳转到 pdfsail.com Ready 页面
    window.location.href = "https://www.pdfsail.com/ready";
  };

  if (phase === "idle") {
    return (
      <button
        onClick={start}
        disabled={disabled}
        style={{
          padding: "8px 18px",
          background: disabled ? "#94a3b8" : "linear-gradient(135deg,#10b981,#059669)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          fontSize: 14,
          fontWeight: 600,
          cursor: disabled ? "not-allowed" : "pointer",
          boxShadow: "0 2px 8px rgba(16,185,129,0.3)",
        }}
      >
        ⬇ Download
      </button>
    );
  }

  // 进度条 overlay
  return (
    <>
      <button
        disabled
        style={{
          padding: "8px 18px",
          background: "#94a3b8",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          fontSize: 14,
          fontWeight: 600,
          cursor: "wait",
        }}
      >
        ⏳ {Math.round(progress)}%
      </button>
      {renderToBody(
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15,23,42,0.85)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 99999,
          }}
        >
          <div
            style={{
              background: "#fff",
              borderRadius: 16,
              padding: "40px 48px",
              width: 440,
              textAlign: "center",
              boxShadow: "0 20px 60px rgba(0,0,0,0.3)",
            }}
          >
            <div style={{ fontSize: 48, marginBottom: 16 }}>
              {phase === "preparing" ? "📄" : phase === "uploading" ? "☁️" : phase === "redirecting" ? "🚀" : "✅"}
            </div>
            <div style={{ fontSize: 18, fontWeight: 600, color: "#1e293b", marginBottom: 20 }}>
              {PHASE_LABEL[phase]}
            </div>
            <div
              style={{
                width: "100%",
                height: 8,
                background: "#e2e8f0",
                borderRadius: 4,
                overflow: "hidden",
                marginBottom: 12,
              }}
            >
              <div
                style={{
                  width: `${progress}%`,
                  height: "100%",
                  background: "linear-gradient(90deg,#10b981,#059669)",
                  borderRadius: 4,
                  transition: "width 0.2s ease",
                }}
              />
            </div>
            <div style={{ fontSize: 12, color: "#64748b" }}>{progress}%</div>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
