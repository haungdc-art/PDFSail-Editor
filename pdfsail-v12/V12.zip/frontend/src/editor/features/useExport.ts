/**
 * useExport — Commit 3 / Feature 3
 *
 * 导出业务能力：检查免费额度 + 应用 blocks 到 PDF + 下载。
 * 从 PDFEditor.tsx L444-464 提取。
 *
 * Ref 由 PDFEditorInner 持有并注入：
 *   coordRef / pdfBytesRef / cssScaleRef
 */

import { useEditor } from "../core/EditorProvider";
import { exportPDF, downloadPDF } from "../export-pdf";
import type { LockCoordSystem } from "../coord";

interface UseExportParams {
  coordRef: React.MutableRefObject<LockCoordSystem | null>;
  pdfBytesRef: React.MutableRefObject<ArrayBuffer | null>;
  cssScaleRef: React.MutableRefObject<number>;
}

export function useExport({ coordRef, pdfBytesRef, cssScaleRef }: UseExportParams) {
  const { docBlocks, fileName, setShowPayModal } = useEditor();

  const handleExport = async (skipPay?: boolean) => {
    if (!coordRef.current || !pdfBytesRef.current) return;
    if (!skipPay) {
      try {
        const res = await fetch("/api/billing/usage");
        const usage = await res.json();
        if (usage.exportsRemaining > 0) {
          // 有免费额度，直接导出
        } else {
          setShowPayModal(true);
          return;
        }
      } catch {
        // 后端不可用时默认允许导出
      }
    }
    const s = cssScaleRef.current;
    const pxBlocks = docBlocks.map((b) => ({ ...b, x: b.x / s, y: b.y / s, w: b.w / s, h: b.h / s }));
    const bytes = await exportPDF(pxBlocks, coordRef.current, pdfBytesRef.current);
    downloadPDF(bytes, `edited-${fileName || "output"}.pdf`);
  };

  return { handleExport };
}
