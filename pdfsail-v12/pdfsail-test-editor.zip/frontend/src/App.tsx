import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { routes, RouteConfig } from "./routing/routes";

function renderRoute(route: RouteConfig) {
  return (
    <Route
      key={route.path}
      path={route.path}
      element={route.element}
    />
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* Navigation */}
        <nav
          style={{
            background: "#1a1a2e",
            color: "#fff",
            padding: "16px 24px",
            display: "flex",
            alignItems: "center",
            gap: 32,
          }}
        >
          <a
            href="/"
            style={{
              color: "#fff",
              fontSize: 20,
              fontWeight: 700,
              textDecoration: "none",
            }}
          >
            PDFSail
          </a>
          <div style={{ display: "flex", gap: 20, fontSize: 14 }}>
            <a href="/editor" style={{ color: "#ccc", textDecoration: "none" }}>
              Editor
            </a>
            <a
              href="/smallpdf-alternative"
              style={{ color: "#ccc", textDecoration: "none" }}
            >
              Smallpdf Alternative
            </a>
            <a
              href="/ilovepdf-alternative"
              style={{ color: "#ccc", textDecoration: "none" }}
            >
              iLovePDF Alternative
            </a>
            <a
              href="/pdf24-alternative"
              style={{ color: "#ccc", textDecoration: "none" }}
            >
              PDF24 Alternative
            </a>
            <a href="/admin" style={{ color: "#7c5cfc", textDecoration: "none", fontWeight: 600 }}>
              Admin
            </a>
          </div>
        </nav>

        {/* Main Content */}
        <main style={{ flex: 1 }}>
          <Routes>{routes.map(renderRoute)}</Routes>
        </main>

        {/* Footer */}
        <footer
          style={{
            background: "#1a1a2e",
            color: "#888",
            padding: "24px",
            textAlign: "center",
            fontSize: 13,
          }}
        >
          <p>PDFSail V12 — Free Online PDF Tools</p>
          <p style={{ marginTop: 4 }}>
            Edit, Merge, Compress, Convert & Sign PDFs Online
          </p>
        </footer>
      </div>
    </BrowserRouter>
  );
}
