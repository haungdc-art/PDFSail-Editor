export class UndoRedo<T> {
  private stack: T[] = [];
  private index = -1;
  private maxSize: number;

  constructor(initial: T, maxSize = 50) {
    this.stack = [initial];
    this.index = 0;
    this.maxSize = maxSize;
  }

  push(state: T) {
    // Discard any redo states
    this.stack = this.stack.slice(0, this.index + 1);
    this.stack.push(JSON.parse(JSON.stringify(state)));
    if (this.stack.length > this.maxSize) this.stack.shift();
    this.index = this.stack.length - 1;
  }

  undo(): T | null {
    if (this.index <= 0) return null;
    this.index--;
    return JSON.parse(JSON.stringify(this.stack[this.index]));
  }

  redo(): T | null {
    if (this.index >= this.stack.length - 1) return null;
    this.index++;
    return JSON.parse(JSON.stringify(this.stack[this.index]));
  }

  get canUndo() {
    return this.index > 0;
  }

  get canRedo() {
    return this.index < this.stack.length - 1;
  }
}
