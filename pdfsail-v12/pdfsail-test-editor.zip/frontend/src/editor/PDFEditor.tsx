import React, { useEffect, useRef, useState, useCallback } from "react";
import { createPortal } from "react-dom";
import { v4 as uuid } from "uuid";
import * as pdfjsLib from "pdfjs-dist";
import Tesseract from "tesseract.js";
import { PDFDocument } from "pdf-lib";
import type { Block, TextBlock } from "./types";
import { exportPDF, downloadPDF } from "./export-pdf";
import SignaturePad from "./SignaturePad";
import { UndoRedo } from "./undo-redo";
import { LockCoordSystem } from "./coord";
// Inline tool imports
import { compressPDF } from "../compress/compress-core";
import { splitPDF } from "../split/split-core";
import { rotatePDF } from "../rotate/rotate-core";
import { addPageNumbers } from "../pagenum/pagenum-core";
import { convertPdfToDocx } from "../pdftoword/pdftoword-core";
import { convertPdfToExcel } from "../pdftoexcel/pdftoexcel-core";
import { removeWatermark } from "../watermark/watermark-core";

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
  "pdfjs-dist/build/pdf.worker.min.mjs",
  import.meta.url
).toString();

export default function PDFEditor() {
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [pdfDoc, setPdfDoc] = useState<pdfjsLib.PDFDocumentProxy | null>(null);
  const [fileName, setFileName] = useState("");
  const [docBlocks, setDocBlocks] = useState<Block[]>([]);
  const [textItems, setTextItems] = useState<any[]>([]);
  const [showTextLayer, setShowTextLayer] = useState(true);
  const [ocrBusy, setOcrBusy] = useState(false);
  const [showSignature, setShowSignature] = useState(false);
  const [addingType, setAddingType] = useState<"image" | "highlight" | "ocr" | "redact" | "annotate" | null>(null);
  const [editingBlock, setEditingBlock] = useState<{ id: string; text: string; x: number; y: number; w: number; h: number; fontSize: number } | null>(null);
  const [ocrSelect, setOcrSelect] = useState<{ startX: number; startY: number; endX: number; endY: number } | null>(null);
  const [textFormat, setTextFormat] = useState({ fontFamily: "'SimSun','Songti SC','Noto Serif CJK SC',serif", fontSize: 14, color: "#000000" });
  const [highlightFormat, setHighlightFormat] = useState<{ type: "text" | "freehand" | "underline" | "strike" | "wavy"; color: string; opacity: number }>({ type: "text", color: "#facc15", opacity: 40 });
  const [annoFormat, setAnnoFormat] = useState<{ aType: "note" | "highlight" | "strike" | "underline"; color: string }>({ aType: "note", color: "#3b82f6" });
  const [showTools, setShowTools] = useState(false);
  const [selectedBlockId, setSelectedBlockId] = useState<string | null>(null);
  const [thumbnails, setThumbnails] = useState<string[]>([]);
  const [thumbnailCol, setThumbnailCol] = useState(true);
  // Inline processing state
  const [processingTool, setProcessingTool] = useState<string | null>(null);
  const [processingLog, setProcessingLog] = useState<string[]>([]);
  // Tool option modals
  const [showCompressOptions, setShowCompressOptions] = useState(false);
  const [showSplitOptions, setShowSplitOptions] = useState(false);
  const [showRotateOptions, setShowRotateOptions] = useState(false);
  const [showPageNumOptions, setShowPageNumOptions] = useState(false);
  // Workspace mode
  const [workspaceMode, setWorkspaceMode] = useState(false);
  const [showIntentModal, setShowIntentModal] = useState(false);
  const [wsAction, setWsAction] = useState<{ label: string; action: string; reason: string } | null>(null);
  const [wsHints, setWsHints] = useState<{ type: string; text: string; action: string }[]>([]);
  const [wsActionsDone, setWsActionsDone] = useState<string[]>([]);
  const [wsShowFlow, setWsShowFlow] = useState(false);
  const [splitMode, setSplitMode] = useState<"all" | "range">("all");
  const [splitRange, setSplitRange] = useState<[number, number]>([1, 1]);
  const [rotateDeg, setRotateDeg] = useState<90 | 180 | 270>(90);
  const [rotateMode, setRotateMode] = useState<"all" | "current">("all");
  const [pageNumOpts, setPageNumOpts] = useState({ position: "bottom" as const, align: "center" as const, format: "Page %d", startFrom: 1, fontSize: 12, color: "#333333" });
  const [compressQuality, setCompressQuality] = useState(60);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const coordRef = useRef<LockCoordSystem | null>(null);
  const dragRef = useRef<{ id: string; ox: number; oy: number; ox0: number; oy0: number } | null>(null);
  const cssScaleRef = useRef(1); // canvas.clientWidth / canvas.width
  const undoRef = useRef(new UndoRedo<Block[]>([]));
  const pdfBytesRef = useRef<ArrayBuffer | null>(null);
  const pdfLibDocRef = useRef<PDFDocument | null>(null);

  const pushUndo = useCallback(() => undoRef.current.push(docBlocks), [docBlocks]);
  useEffect(() => { pushUndo(); }, []);

  const setBlocks = useCallback((fn: Block[] | ((prev: Block[]) => Block[])) => {
    setDocBlocks((prev) => {
      const next = typeof fn === "function" ? (fn as (p: Block[]) => Block[])(prev) : fn;
      return next;
    });
    setTimeout(pushUndo, 0);
  }, [pushUndo]);

  // 选中 block 时同步工具栏
  useEffect(() => {
    if (!selectedBlockId) return;
    const b = docBlocks.find((x) => x.id === selectedBlockId);
    if (b && b.type === "text") {
      setTextFormat((prev) => ({
        fontFamily: b.fontFamily || prev.fontFamily,
        fontSize: b.fontSize || prev.fontSize,
        color: b.color || prev.color,
      }));
    }
  }, [selectedBlockId]);

  const handleUndo = useCallback(() => { const s = undoRef.current.undo(); if (s) setDocBlocks(s); }, []);
  const handleRedo = useCallback(() => { const s = undoRef.current.redo(); if (s) setDocBlocks(s); }, []);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "z") { e.preventDefault(); if (e.shiftKey) handleRedo(); else handleUndo(); }
      if ((e.ctrlKey || e.metaKey) && e.key === "y") { e.preventDefault(); handleRedo(); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [handleUndo, handleRedo]);

  // Render PDF
  useEffect(() => {
    if (!pdfDoc || !canvasRef.current) return;
    let done = false;
    (async () => {
      const pg = await pdfDoc.getPage(page);
      const vp = pg.getViewport({ scale: 1.5 });
      const canvas = canvasRef.current!;
      canvas.width = vp.width;
      canvas.height = vp.height;
      await pg.render({ canvasContext: canvas.getContext("2d")!, viewport: vp }).promise;
      if (done) return;

      // CSS display scale — canvas pixel vs CSS display
      cssScaleRef.current = canvas.clientWidth / canvas.width;

      coordRef.current = new LockCoordSystem({ scale: 1.5, width: vp.width, height: vp.height });

      // Extract text → CSS display coords (canvas px × cssScale)
      const tc = await pg.getTextContent();
      const s = cssScaleRef.current;
      setTextItems(
        tc.items.filter((i: any) => i.str?.trim()).map((i: any) => {
          const c = coordRef.current!.fromPDF(i);
          return { id: crypto.randomUUID(), text: i.str, x: c.x * s, y: c.y * s, w: c.w * s, h: c.h * s, fontSize: c.fontSize * s };
        })
      );
    })();
    return () => { done = true; };
  }, [pdfDoc, page]);

  // Drag + Resize
  useEffect(() => {
    const move = (e: MouseEvent) => {
      if (dragRef.current) {
        setDocBlocks((prev) =>
          prev.map((b) =>
            b.id === dragRef.current!.id
              ? { ...b, x: dragRef.current!.ox0 + e.clientX - dragRef.current!.ox, y: dragRef.current!.oy0 + e.clientY - dragRef.current!.oy }
              : b
          )
        );
      }
      if (resizeRef.current) {
        setDocBlocks((prev) =>
          prev.map((b) =>
            b.id === resizeRef.current!.id
              ? { ...b, w: Math.max(30, resizeRef.current!.initW + e.clientX - resizeRef.current!.startX), h: Math.max(30, resizeRef.current!.initH + e.clientY - resizeRef.current!.startY) }
              : b,
          )
        );
      }
    };
    const up = () => { dragRef.current = null; resizeRef.current = null; };
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
    return () => { window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", up); };
  }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setDocBlocks([]);
    setTextItems([]);
    const buf = await file.arrayBuffer();
    pdfBytesRef.current = buf;
    pdfLibDocRef.current = await PDFDocument.load(buf.slice(0), { ignoreEncryption: true });
    const pdf = await pdfjsLib.getDocument({ data: buf.slice(0), cMapUrl: "/cmaps/", cMapPacked: true, standardFontDataUrl: "/standard_fonts/" }).promise;
    setPdfDoc(pdf);
    setTotalPages(pdf.numPages);
    setPage(1);
    renderThumbnails(pdf);
    if (workspaceMode) setShowIntentModal(true);
  };

  async function renderThumbnails(pdf: pdfjsLib.PDFDocumentProxy) {
    const n = pdf.numPages;
    const urls: string[] = new Array(n).fill("");
    setThumbnails([...urls]);
    for (let i = 1; i <= n; i++) {
      try {
        const pg = await pdf.getPage(i);
        const vp = pg.getViewport({ scale: 0.4 });
        const c = document.createElement("canvas");
        c.width = Math.round(vp.width);
        c.height = Math.round(vp.height);
        const ctx = c.getContext("2d");
        if (!ctx) { continue; }
        // 白色背景
        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, c.width, c.height);
        await pg.render({ canvasContext: ctx, viewport: vp }).promise;
        urls[i - 1] = c.toDataURL();
        setThumbnails([...urls]);
      } catch (e) {
        console.error("Thumbnail error p", i, e);
      }
    }
  }

  async function runInlineOCR(image: string, page: number, cssScale: number, psm?: number): Promise<TextBlock[]> {
    const scale = 2;
    const img = await upscaleImageNN(image, scale);
    const res = await Tesseract.recognize(img, "chi_sim+eng", {
      logger: () => {},
      ...(psm ? { tessedit_pageseg_mode: String(psm) } : {}),
    });

    const words = (res.data.words as any[])
      .filter((w) => w.text?.trim())
      .filter((w) => (w.confidence ?? 0) > 35)
      .filter((w) => {
        const wW = w.bbox.x1 - w.bbox.x0;
        const wH = w.bbox.y1 - w.bbox.y0;
        const ratio = Math.max(wW, wH) / Math.max(Math.min(wW, wH), 1);
        return wW > 3 && wH > 3 && ratio < 15;
      });

    const sorted = [...words].sort((a, b) => {
      if (Math.abs(a.bbox.y0 - b.bbox.y0) < 12) return a.bbox.x0 - b.bbox.x0;
      return a.bbox.y0 - b.bbox.y0;
    });

    const groups: any[][] = [];
    let current: any[] = [];
    for (const w of sorted) {
      if (!current.length) { current = [w]; continue; }
      const last = current[current.length - 1];
      const sameLine = Math.abs(w.bbox.y0 - last.bbox.y0) < 12;
      const closeX = w.bbox.x0 - last.bbox.x1 < 30; // upscale px => 15 CSS px
      if (sameLine && closeX) current.push(w);
      else { groups.push(current); current = [w]; }
    }
    if (current.length) groups.push(current);

    return groups.map((g) => {
      const x0 = g[0].bbox.x0;
      const y0 = Math.min(...g.map((w) => w.bbox.y0));
      const x1 = g[g.length - 1].bbox.x1;
      const y1 = Math.max(...g.map((w) => w.bbox.y1));
      // 使用每组中所有 word 高度的中位数，避免个别 word 错位导致 fontSize 忽大忽小
      const heights = g.map((w) => w.bbox.y1 - w.bbox.y0).sort((a: number, b: number) => a - b);
      const medianH = heights.length % 2 === 0
        ? (heights[heights.length / 2 - 1] + heights[heights.length / 2]) / 2
        : heights[Math.floor(heights.length / 2)];
      const h = Math.max(medianH / scale, 1);
      const fontSize = Math.max(h * 0.85 * cssScale, 8);
      return {
        id: crypto.randomUUID(),
        type: "text" as const,
        page,
        x: (x0 / scale) * cssScale,
        y: (y0 / scale) * cssScale,
        w: ((x1 - x0) / scale) * cssScale,
        h: ((y1 - y0) / scale) * cssScale,
        text: g.map((w) => w.text).join(""),
        fontSize,
      } as TextBlock;
    });
  }

  function mergeTextRects(items: { x: number; y: number; w: number; h: number }[], yThresh = 12, xGap = 20) {
    if (!items.length) return [];
    const sorted = [...items].sort((a, b) => {
      if (Math.abs(a.y - b.y) < yThresh) return a.x - b.x;
      return a.y - b.y;
    });
    const groups: typeof items[] = [];
    let current: typeof items = [];
    for (const it of sorted) {
      if (!current.length) { current = [it]; continue; }
      const last = current[current.length - 1];
      const sameLine = Math.abs(it.y - last.y) < yThresh;
      const closeX = it.x - (last.x + last.w) < xGap;
      if (sameLine && closeX) current.push(it);
      else { groups.push(current); current = [it]; }
    }
    if (current.length) groups.push(current);
    return groups.map((g) => ({
      l: Math.min(...g.map((i) => i.x)),
      r: Math.max(...g.map((i) => i.x + i.w)),
      t: Math.min(...g.map((i) => i.y)),
      b: Math.max(...g.map((i) => i.y + i.h)),
    }));
  }

  /** 最近邻放大 2x，保持原始像素不模糊 */
  async function upscaleImageNN(dataUrl: string, scale: number): Promise<string> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        const ctx = canvas.getContext("2d")!;
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/png"));
      };
      img.onerror = reject;
      img.src = dataUrl;
    });
  }

  const handleOCR = async () => {
    if (!canvasRef.current || ocrBusy) return;
    setOcrBusy(true);
    try {
      const canvas = canvasRef.current;
      const s = cssScaleRef.current;

      const textRects = mergeTextRects(
        textItems.map((t) => ({ x: t.x, y: t.y, w: t.w, h: t.h })),
        12,
        20
      ).map((r) => ({ l: r.l - 5, r: r.r + 5, t: r.t - 5, b: r.b + 5 }));

      const blocks = await runInlineOCR(canvas.toDataURL("image/png"), page, s);

      // 过滤：只要 OCR 块中心点落在文本区域内，或超过 50% 面积重叠，就判定为正文文本
      let filtered = blocks.filter((b) => {
        const bl = b.x, br = b.x + b.w;
        const bt = b.y, bb = b.y + b.h;
        const bArea = Math.max((br - bl) * (bb - bt), 1);
        const cx = (bl + br) / 2;
        const cy = (bt + bb) / 2;
        let totalOverlap = 0;
        let centerInside = false;
        for (const tr of textRects) {
          const il = Math.max(bl, tr.l);
          const ir = Math.min(br, tr.r);
          const it = Math.max(bt, tr.t);
          const ib = Math.min(bb, tr.b);
          if (il < ir && it < ib) {
            totalOverlap += (ir - il) * (ib - it);
          }
          if (cx >= tr.l && cx <= tr.r && cy >= tr.t && cy <= tr.b) {
            centerInside = true;
          }
        }
        // 中心在文本内 或 超过 50% 面积重叠 → 丢弃
        return !centerInside && totalOverlap / bArea < 0.5;
      });

      // 字号归一化：用全页中位数，把偏离太大的修正到 ±30% 内
      const sizes = filtered.map((b) => b.fontSize).filter((v): v is number => typeof v === "number").sort((a, b) => a - b);
      if (sizes.length > 2) {
        const mid = Math.floor(sizes.length / 2);
        const median = sizes.length % 2 === 0
          ? (sizes[mid - 1] + sizes[mid]) / 2
          : sizes[mid];
        filtered = filtered.map((b) => ({
          ...b,
          fontSize: typeof b.fontSize === "number"
            ? Math.max(median * 0.7, Math.min(median * 1.3, b.fontSize))
            : b.fontSize,
        }));
      }

      setBlocks((prev) => [...prev, ...filtered]);
    } catch (err) { console.error(err); }
    setOcrBusy(false);
  };

  const handleOCRRegion = async (x: number, y: number, w: number, h: number) => {
    if (!canvasRef.current || ocrBusy) return;
    if (w < 20 || h < 20) return;
    setOcrBusy(true);
    try {
      const canvas = canvasRef.current;
      const s = cssScaleRef.current;
      // CSS → canvas pixel for cropping
      const cx = x / s, cy = y / s, cw = w / s, ch = h / s;
      const offscreen = document.createElement("canvas");
      offscreen.width = cw;
      offscreen.height = ch;
      const ctx = offscreen.getContext("2d")!;
      ctx.drawImage(canvas, cx, cy, cw, ch, 0, 0, cw, ch);
      const regionDataUrl = offscreen.toDataURL("image/png");
      const blocks = await runInlineOCR(regionDataUrl, page, s, 6); // PSM 6: single text block
      // Translate OCR coords (relative to region) → page CSS coords
      blocks.forEach((b) => { b.x += x; b.y += y; });
      setBlocks((prev) => [...prev, ...blocks]);
    } catch (err) { console.error(err); }
    setOcrBusy(false);
  };

  const reloadFromPdfLib = async () => {
    if (!pdfLibDocRef.current) return;
    const bytes = await pdfLibDocRef.current.save();
    pdfBytesRef.current = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
    const pdf = await pdfjsLib.getDocument({ data: bytes, cMapUrl: "/cmaps/", cMapPacked: true, standardFontDataUrl: "/standard_fonts/" }).promise;
    setPdfDoc(pdf);
    setTotalPages(pdf.numPages);
    return pdf;
  };

  const handleAddBlankPage = async () => {
    if (!pdfLibDocRef.current) return;
    const current = page - 1;
    const size = pdfLibDocRef.current.getPage(current).getSize();
    pdfLibDocRef.current.insertPage(page, [size.width, size.height]);
    // update blocks on/after current page: shift forward by 1
    setDocBlocks((prev) => prev.map((b) => ({ ...b, page: b.page >= page ? b.page + 1 : b.page })));
    await reloadFromPdfLib();
    setPage(page + 1);
  };

  const handleMovePageUp = async () => {
    if (!pdfLibDocRef.current || page <= 1) return;
    const newOrder: number[] = [];
    for (let i = 0; i < totalPages; i++) {
      if (i === page - 2) newOrder.push(page - 1); // current page moved to previous position
      else if (i === page - 1) newOrder.push(page - 2); // previous page moved to current position
      else newOrder.push(i);
    }
    const nextDoc = await PDFDocument.create();
    const pages = await nextDoc.copyPages(pdfLibDocRef.current, newOrder);
    pages.forEach((p) => nextDoc.addPage(p));
    pdfLibDocRef.current = nextDoc;
    setDocBlocks((prev) => prev.map((b) => {
      if (b.page === page) return { ...b, page: page - 1 };
      if (b.page === page - 1) return { ...b, page: page };
      return b;
    }));
    await reloadFromPdfLib();
    setPage(page - 1);
  };

  const handleMovePageDown = async () => {
    if (!pdfLibDocRef.current || page >= totalPages) return;
    const newOrder: number[] = [];
    for (let i = 0; i < totalPages; i++) {
      if (i === page - 1) newOrder.push(page); // current page moved to next position
      else if (i === page) newOrder.push(page - 1); // next page moved to current position
      else newOrder.push(i);
    }
    const nextDoc = await PDFDocument.create();
    const pages = await nextDoc.copyPages(pdfLibDocRef.current, newOrder);
    pages.forEach((p) => nextDoc.addPage(p));
    pdfLibDocRef.current = nextDoc;
    setDocBlocks((prev) => prev.map((b) => {
      if (b.page === page) return { ...b, page: page + 1 };
      if (b.page === page + 1) return { ...b, page: page };
      return b;
    }));
    await reloadFromPdfLib();
    setPage(page + 1);
  };

  const handleDeletePage = async () => {
    if (!pdfLibDocRef.current || totalPages <= 1) return;
    pdfLibDocRef.current.removePage(page - 1);
    setDocBlocks((prev) => prev.filter((b) => b.page !== page).map((b) => b.page > page ? { ...b, page: b.page - 1 } : b));
    await reloadFromPdfLib();
    setPage((p) => Math.min(p, totalPages - 1));
  };

  const [showPayModal, setShowPayModal] = useState(false);

  const handleExport = async (skipPay?: boolean) => {
    if (!coordRef.current || !pdfBytesRef.current) return;
    if (!skipPay) {
      try {
        const res = await fetch("/api/billing/usage");
        const usage = await res.json();
        if (usage.exportsRemaining > 0) {
          // 有免费额度，直接导出
        } else {
          setShowPayModal(true);
          return;
        }
      } catch {
        // 后端不可用时默认允许导出
      }
    }
    const s = cssScaleRef.current;
    const pxBlocks = docBlocks.map((b) => ({ ...b, x: b.x / s, y: b.y / s, w: b.w / s, h: b.h / s }));
    const bytes = await exportPDF(pxBlocks, coordRef.current, pdfBytesRef.current);
    downloadPDF(bytes, `edited-${fileName || "output"}.pdf`);
  };

  const handlePaypalPay = async () => {
    try {
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ method: "paypal", productKey: "pdfExport" }),
      });
      const data = await res.json();
      if (data.url) {
        window.open(data.url, "_blank");
        // 在 PayPal 页面打开后允许用户返回时继续导出
        setShowPayModal(false);
      } else if (data.mockMode) {
        // Mock 模式：直接导出
        setShowPayModal(false);
        handleExport(true);
      }
    } catch (err) {
      console.error("PayPal error:", err);
      setShowPayModal(false);
    }
  };

  const handleStripePay = async () => {
    try {
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ method: "stripe", productKey: "pdfExport" }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else if (data.mockMode) {
        setShowPayModal(false);
        handleExport(true);
      }
    } catch (err) {
      console.error("Stripe error:", err);
      setShowPayModal(false);
    }
  };

  const updateSelectedFormat = (patch: Partial<{ fontFamily: string; fontSize: number; color: string }>) => {
    if (!selectedBlockId) return;
    setBlocks((prev) => prev.map((b) => b.id === selectedBlockId && b.type === "text" ? { ...b, ...patch } as TextBlock : b));
  };

  const addBlock = (type: Block["type"], extra: any = {}) => {
    setBlocks((prev) => [...prev, { id: uuid(), type, page, x: 100, y: 100, w: 100, h: 30, ...extra } as Block]);
  };

  const imageInputRef = useRef<HTMLInputElement>(null);
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      addBlock("image", { src: reader.result as string, w: 160, h: 160 });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };
  // resize drag state
  const resizeRef = useRef<{ id: string; startX: number; startY: number; initW: number; initH: number } | null>(null);

  const pageBlocks = docBlocks.filter((b) => b.page === page);

  // ── Inline Tool Processing ──

  const processInline = useCallback(async (tool: string, extra: any = {}) => {
    if (!pdfBytesRef.current && !pdfDoc) return;
    setProcessingTool(tool);
    setProcessingLog([`Starting: ${tool}...`]);
    addLog(`Loading document bytes...`);

    // If there are edits, export first to get final bytes
    let sourceBytes: Uint8Array;
    if (docBlocks.length > 0 && coordRef.current) {
      addLog(`Applying ${docBlocks.length} edit(s) to source PDF...`);
      sourceBytes = await exportPDF(docBlocks, coordRef.current, pdfBytesRef.current?.slice(0));
      addLog(`Edits applied successfully.`);
    } else {
      sourceBytes = new Uint8Array(pdfBytesRef.current?.slice(0) || []);
    }

    try {
      let result: Uint8Array | Blob | null = null;
      let fileName = "";

      switch (tool) {
        case "compress": {
          addLog(`Compressing PDF (quality: ${extra.quality || 60})...`);
          const r = await compressPDF(sourceBytes, extra.quality || 60);
          result = new Uint8Array(r.bytes);
          fileName = `compressed_${r.ratio.toFixed(0)}pct.pdf`;
          addLog(`Compressed: ${(r.originalSize / 1024).toFixed(0)}KB → ${(r.compressedSize / 1024).toFixed(0)}KB (${r.ratio.toFixed(0)}%)`);
          break;
        }
        case "split": {
          addLog(`Splitting PDF (mode: ${extra.mode})...`);
          const r = await splitPDF(sourceBytes, extra.mode as any, extra.range);
          if (r.pages.length === 1) {
            result = new Uint8Array(r.pages[0].bytes);
            fileName = `page_${r.pages[0].index + 1}.pdf`;
          } else {
            // Download all as zip-like individual files
            for (const p of r.pages) {
              downloadPDF(new Uint8Array(p.bytes), `page_${p.index + 1}.pdf`);
            }
            addLog(`Downloaded ${r.pages.length} individual page(s).`);
            setProcessingTool(null);
            return;
          }
          addLog(`Split: ${r.totalPages} pages into ${r.pages.length} file(s).`);
          break;
        }
        case "rotate": {
          addLog(`Rotating PDF (${extra.degrees}°, mode: ${extra.mode})...`);
          const r = await rotatePDF(sourceBytes, extra.degrees as any, extra.mode as any, extra.pageIndex || 0);
          result = new Uint8Array(r);
          fileName = `rotated_${extra.degrees}.pdf`;
          addLog(`Rotation complete.`);
          break;
        }
        case "pagenum": {
          addLog(`Adding page numbers (${extra.opts.position}, ${extra.opts.align})...`);
          const r = await addPageNumbers(sourceBytes, extra.opts);
          result = new Uint8Array(r);
          fileName = `numbered.pdf`;
          addLog(`Page numbers added to ${totalPages} pages.`);
          break;
        }
        case "word": {
          addLog(`Converting PDF to Word...`);
          const r = await convertPdfToDocx(sourceBytes);
          result = r.blob;
          fileName = `converted.docx`;
          addLog(`Conversion complete (quality: ${(r.quality * 100).toFixed(0)}%).`);
          if (r.paywall !== "free") addLog(`⚠ ${r.paywall} tier — price: $${r.price}`);
          break;
        }
        case "excel": {
          addLog(`Converting PDF to Excel...`);
          const r = await convertPdfToExcel(sourceBytes);
          result = r.blob;
          fileName = `converted.xlsx`;
          addLog(`Converted: ${r.rowCount} rows × ${r.colCount} cols (confidence: ${(r.tableConfidence * 100).toFixed(0)}%).`);
          if (r.paywall !== "free") addLog(`⚠ ${r.paywall} tier — price: $${r.price}`);
          break;
        }
        case "watermark": {
          addLog(`Analyzing and removing watermarks...`);
          const r = await removeWatermark(sourceBytes);
          result = r.blob;
          fileName = `cleaned.pdf`;
          addLog(`Removed ${r.removed} watermark(s) across ${r.pagesAffected} pages.`);
          addLog(`Intent: ${r.intent} | Confidence: ${(r.confidence * 100).toFixed(0)}%`);
          if (r.paywall !== "free") addLog(`⚠ ${r.paywall} tier — price: $${r.price}`);
          break;
        }
      }

      if (result) {
        addLog(`✅ ${tool} complete. Downloading...`);
        const blob = result instanceof Blob ? result : new Blob([result], { type: "application/octet-stream" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url; a.download = fileName; a.click();
        URL.revokeObjectURL(url);
        addLog(`📥 Downloaded: ${fileName}`);
      }
      // Update workspace state
      if (workspaceMode) {
        setWsActionsDone((prev) => [...prev, tool]);
        setWsShowFlow(true);
        setWsAction(null);
      }
    } catch (err: any) {
      addLog(`❌ Error: ${err.message}`);
    } finally {
      setTimeout(() => setProcessingTool(null), 1500);
    }
  }, [docBlocks, pdfDoc, pdfBytesRef, coordRef, totalPages, workspaceMode]);

  const addLog = useCallback((msg: string) => {
    setProcessingLog((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
  }, []);

  // ── Workspace Helpers ──

  const generateLocalHints = useCallback((items: any[]) => {
    const hints: { type: string; text: string; action: string }[] = [];
    const allText = items.map((t: any) => t.text || "").join(" ").toLowerCase();
    if (allText.includes("|") || allText.includes("table") || /\d{2,}%/.test(allText)) {
      hints.push({ type: "STRUCTURED_DATA", text: "Table-like content detected — extract", action: "extract_tables" });
    }
    if (["invoice", "amount", "total", "tax", "payment", "balance", "usd"].some((k) => allText.includes(k))) {
      hints.push({ type: "FINANCIAL", text: "Financial data found — ready for analysis", action: "extract_tables" });
    }
    if (["agreement", "contract", "party", "terms"].some((k) => allText.includes(k))) {
      hints.push({ type: "CONTRACT", text: "Contract terms detected — convert to editable", action: "convert_word" });
    }
    if (items.length < 10) {
      hints.push({ type: "SCANNED", text: "Scanned content — OCR available", action: "ocr_text" });
    }
    return hints.slice(0, 2);
  }, []);

  // Show intent modal after upload if workspace mode
  const origUpload = handleUpload;
  // We can't replace the ref, but we'll trigger in the toolbar UI

  return (
    <div style={{ border: "1px solid #e2e8f0", borderRadius: 12, background: "#fff", boxShadow: "0 2px 12px rgba(0,0,0,0.06)", overflow: "hidden" }}>
      <div style={{ display: "flex" }}>
        {/* ── 左侧缩略图面板（可收展） ── */}
        {pdfDoc && (
          <div style={{
            width: thumbnailCol ? 150 : 28,
            flexShrink: 0,
            background: "#f8fafc",
            borderRight: "1px solid #e2e8f0",
            transition: "width 0.2s",
            position: "relative",
            overflow: "hidden",
          }}>
            {thumbnailCol ? (
              <>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 10px 4px" }}>
                  <span style={{ fontSize: 11, fontWeight: 700, color: "#64748b" }}>Pages {thumbnails.length > 0 ? `(${thumbnails.length})` : ""}</span>
                  <button onClick={() => setThumbnailCol(false)}
                    style={{ background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: 12, padding: "2px 6px", borderRadius: 3, lineHeight: 1 }}>
                    ◀
                  </button>
                </div>
                <div style={{ padding: "4px 8px 10px", maxHeight: "calc(100vh - 140px)", overflowY: "auto" }}>
                  {thumbnails.map((url, i) => {
                    const pg = i + 1;
                    const isActive = pg === page;
                    return (
                      <div key={pg} onClick={() => setPage(pg)}
                        style={{
                          cursor: "pointer", marginBottom: 6, borderRadius: 6, overflow: "hidden",
                          border: isActive ? "2px solid #3b82f6" : "2px solid transparent",
                          boxShadow: isActive ? "0 0 0 1px #3b82f6" : "0 1px 3px rgba(0,0,0,0.08)",
                          transition: "border 0.15s", position: "relative",
                        }}>
                        {url ? (
                          <img src={url} alt={`Page ${pg}`} style={{ display: "block", width: "100%", height: "auto" }} />
                        ) : (
                          <div style={{ width: "100%", aspectRatio: "0.707", background: "#e2e8f0", display: "flex", alignItems: "center", justifyContent: "center", color: "#94a3b8", fontSize: 10 }}>—</div>
                        )}
                        <div style={{
                          position: "absolute", bottom: 2, right: 2,
                          background: isActive ? "#3b82f6" : "rgba(0,0,0,0.5)",
                          color: "#fff", fontSize: 9, padding: "1px 5px", borderRadius: 3,
                          fontWeight: isActive ? 700 : 500,
                        }}>{pg}</div>
                      </div>
                    );
                  })}
                </div>
              </>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "8px 0" }}>
                <button onClick={() => setThumbnailCol(true)}
                  style={{ background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: 14, padding: "4px", lineHeight: 1 }}>
                  ▶
                </button>
                <span style={{ fontSize: 9, color: "#94a3b8", writingMode: "vertical-rl", marginTop: 8 }}>Pages</span>
              </div>
            )}
          </div>
        )}

        {/* ── 中间：画布区 ── */}
        <div style={{ flex: 1 }}>
        {/* TOOLBAR */}
        <div style={{ display: "flex", gap: 6, marginBottom: 16, alignItems: "center", flexWrap: "wrap" }}>
          <label style={{ padding: "8px 16px", background: "#3b82f6", color: "#fff", borderRadius: 6, cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
            Upload PDF
            <input type="file" accept=".pdf" onChange={handleUpload} style={{ display: "none" }} />
          </label>
          {pdfDoc && !thumbnailCol && (
            <button onClick={() => setThumbnailCol(true)} style={{ padding: "4px 8px", background: "#f1f5f9", border: "1px solid #e2e8f0", borderRadius: 4, cursor: "pointer", fontSize: 11, color: "#64748b" }}>
              📄 Pages
            </button>
          )}
          {pdfDoc && (
            <button onClick={() => setWorkspaceMode((v) => !v)}
              style={{ ...btn, background: workspaceMode ? "#7c5cfc" : "#f1f5f9", borderColor: workspaceMode ? "#7c5cfc" : "#e2e8f0", color: workspaceMode ? "#fff" : "#64748b", fontWeight: workspaceMode ? 700 : 500 }}>
              🧭 {workspaceMode ? "Workspace ON" : "Workspace"}
            </button>
          )}
          {pdfDoc && workspaceMode && wsActionsDone.length === 0 && (
            <button onClick={() => setShowIntentModal(true)} style={{ ...btn, background: "#4ade80", color: "#1a1a2e", fontWeight: 600 }}>Set Intent</button>
          )}
          <div style={sep} />
          <button onClick={() => addBlock("text", { text: "Edit me", fontSize: textFormat.fontSize, fontFamily: textFormat.fontFamily, color: textFormat.color })} style={btn}>T Text</button>
          <button onClick={() => imageInputRef.current?.click()} style={btn}>🖼 Image</button>
          <input ref={imageInputRef} type="file" accept="image/*" onChange={handleImageSelect} style={{ display: "none" }} />
          <button onClick={() => setAddingType(addingType === "highlight" ? null : "highlight")} style={{ ...btn, background: addingType === "highlight" ? "#facc15" : "#f1f5f9", borderColor: addingType === "highlight" ? "#facc15" : "#e2e8f0", color: addingType === "highlight" ? "#fff" : "#64748b", fontWeight: addingType === "highlight" ? 700 : 500 }}>🟡 Highlight</button>
          <button onClick={() => setAddingType(addingType === "redact" ? null : "redact")} style={{ ...btn, background: addingType === "redact" ? "#1e293b" : "#f1f5f9", borderColor: addingType === "redact" ? "#1e293b" : "#e2e8f0", color: addingType === "redact" ? "#fff" : "#64748b", fontWeight: addingType === "redact" ? 700 : 500 }}>⬛ Redact</button>
          <button onClick={() => setShowSignature(true)} style={btn}>✍ Signature</button>
          <button onClick={() => setAddingType(addingType === "annotate" ? null : "annotate")} style={{ ...btn, background: addingType === "annotate" ? "#3b82f6" : "#f1f5f9", borderColor: addingType === "annotate" ? "#3b82f6" : "#e2e8f0", color: addingType === "annotate" ? "#fff" : "#64748b", fontWeight: addingType === "annotate" ? 700 : 500 }}>📌 Annotate</button>
          <div style={sep} />
          <button onClick={() => setShowTextLayer((v) => !v)} style={{ ...btn, background: showTextLayer ? "#3b82f6" : "#f1f5f9", borderColor: showTextLayer ? "#3b82f6" : "#e2e8f0", color: showTextLayer ? "#fff" : "#64748b", fontWeight: showTextLayer ? 700 : 500 }}>✏️ Edit</button>
          <div style={sep} />
          <button onClick={handleUndo} style={{ ...btn, opacity: undoRef.current.canUndo ? 1 : 0.35 }} disabled={!undoRef.current.canUndo}>↩ Undo</button>
          <button onClick={handleRedo} style={{ ...btn, opacity: undoRef.current.canRedo ? 1 : 0.35 }} disabled={!undoRef.current.canRedo}>↪ Redo</button>
          <div style={sep} />
          <button onClick={handleOCR} style={{ ...btn, background: ocrBusy ? "#94a3b8" : "#f59e0b", color: "#fff" }} disabled={ocrBusy || !pdfDoc}>{ocrBusy ? "⏳ OCR..." : "🔍 OCR Page"}</button>
          <button onClick={() => setAddingType(addingType === "ocr" ? null : "ocr")} style={{ ...btn, background: addingType === "ocr" ? "#8b5cf6" : "#f1f5f9", borderColor: addingType === "ocr" ? "#8b5cf6" : "#e2e8f0", color: addingType === "ocr" ? "#fff" : "#64748b", fontWeight: addingType === "ocr" ? 700 : 500 }} disabled={ocrBusy || !pdfDoc}>🎯 OCR Region</button>
          <div style={sep} />
          <div style={{ position: "relative" }}>
            <button onClick={() => setShowTools((v) => !v)} style={{ ...btn, background: "linear-gradient(135deg,#8b5cf6,#ec4899)", color: "#fff", fontWeight: 600 }}>🔧 Convert ▾</button>
            {showTools && (
              <div style={{ position: "absolute", top: "100%", left: 0, marginTop: 4, background: "#fff", borderRadius: 8, boxShadow: "0 4px 20px rgba(0,0,0,0.15)", border: "1px solid #e2e8f0", zIndex: 100, minWidth: 200, overflow: "hidden" }}
                onMouseLeave={() => setShowTools(false)}>
                {[
                  { label: "📦 Compress PDF", key: "compress", needsOpts: true },
                  { label: "✂️ Split PDF", key: "split", needsOpts: true },
                  { label: "🔄 Rotate PDF", key: "rotate", needsOpts: true },
                  { label: "🔢 Add Page Numbers", key: "pagenum", needsOpts: true },
                  { label: "📝 PDF to Word", key: "word", needsOpts: false },
                  { label: "📊 PDF to Excel", key: "excel", needsOpts: false },
                  { label: "🧹 Remove Watermark", key: "watermark", needsOpts: false },
                  { label: "🔗 Merge PDF", key: "merge", needsOpts: false },
                ].map((item) => {
                  const handleClick = () => {
                    setShowTools(false);
                    if (item.key === "merge") { window.location.href = "/merge-pdf"; return; }
                    if (!pdfDoc || !pdfBytesRef.current) return;
                    if (item.needsOpts) {
                      if (item.key === "compress") setShowCompressOptions(true);
                      else if (item.key === "split") setShowSplitOptions(true);
                      else if (item.key === "rotate") setShowRotateOptions(true);
                      else if (item.key === "pagenum") setShowPageNumOptions(true);
                      return;
                    }
                    if (item.key === "word") processInline("word");
                    else if (item.key === "excel") processInline("excel");
                    else if (item.key === "watermark") processInline("watermark");
                  };
                  return (
                    <div key={item.key} onClick={handleClick}
                      style={{ display: "block", padding: "10px 16px", color: "#1e293b", fontSize: 13, cursor: "pointer", borderBottom: "1px solid #f1f5f9" }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = "#f8fafc")}
                      onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                      {item.label}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <button onClick={() => handleExport()} style={{ ...btn, background: "#10b981", color: "#fff" }}>📥 Export PDF</button>
          <button onClick={() => { if (docBlocks.length) setBlocks([]); }} style={{ ...btn, color: "#ef4444", borderColor: "#fecaca" }}>🗑 Clear</button>
          {pdfDoc && <span style={{ fontSize: 12, color: "#94a3b8", marginLeft: 4 }}>{fileName} — p.{page}/{totalPages}</span>}
        </div>

        {/* CANVAS */}
        <div style={{ display: "flex", gap: 0, justifyContent: "center", width: "100%" }}>
            <div ref={wrapperRef}
          onClick={(e) => {
            setSelectedBlockId(null);
            if (!addingType || addingType === "ocr" || !wrapperRef.current) return;
            const rect = wrapperRef.current.getBoundingClientRect();
            setBlocks((prev) => [...prev, { id: uuid(), type: addingType, page, x: e.clientX - rect.left, y: e.clientY - rect.top, w: addingType === "image" ? 120 : 60, h: addingType === "image" ? 120 : 30, src: addingType === "image" ? "https://placehold.co/120x120" : undefined } as Block]);
            setAddingType(null);
          }}
          onMouseDown={(e) => {
            if ((addingType !== "ocr" && addingType !== "highlight" && addingType !== "redact" && addingType !== "annotate") || !wrapperRef.current) return;
            const rect = wrapperRef.current.getBoundingClientRect();
            const startX = Math.max(0, e.clientX - rect.left);
            const startY = Math.max(0, e.clientY - rect.top);
            setOcrSelect({ startX, startY, endX: startX, endY: startY });
          }}
          onMouseMove={(e) => {
            if (!ocrSelect || !wrapperRef.current) return;
            const rect = wrapperRef.current.getBoundingClientRect();
            const maxW = wrapperRef.current.clientWidth;
            const maxH = wrapperRef.current.clientHeight;
            setOcrSelect((prev) => prev ? { ...prev, endX: Math.min(maxW, Math.max(0, e.clientX - rect.left)), endY: Math.min(maxH, Math.max(0, e.clientY - rect.top)) } : prev);
          }}
          onMouseUp={() => {
            if (!ocrSelect) return;
            const { startX, startY, endX, endY } = ocrSelect;
            const x = Math.min(startX, endX);
            const y = Math.min(startY, endY);
            const w = Math.abs(endX - startX);
            const h = Math.abs(endY - startY);
            setOcrSelect(null);
            if (addingType === "ocr") {
              setAddingType(null);
              handleOCRRegion(x, y, w, h);
            } else if (addingType === "highlight") {
              setAddingType(null);
              if (w > 10 && h > 10) {
                const selL = x, selR = x + w, selT = y, selB = y + h;
                // 找 selection 内重叠的 textItems
                const overlapping = textItems.filter((t) => {
                  const tl = t.x, tr = t.x + t.w, tt = t.y, tb = t.y + t.h;
                  return tl < selR && tr > selL && tt < selB && tb > selT;
                });
                if (overlapping.length > 0 && (highlightFormat.type === "underline" || highlightFormat.type === "strike" || highlightFormat.type === "wavy")) {
                  // 只取框选垂直范围完全覆盖的行，避免框到相邻行
                  const midY = y + h / 2;
                  const onThisLine = overlapping.filter((t) => Math.abs(t.y + t.h / 2 - midY) < 10);
                  if (onThisLine.length > 0) {
                    const gx = Math.min(...onThisLine.map((i) => i.x));
                    const gy = Math.min(...onThisLine.map((i) => i.y));
                    const gx2 = Math.max(...onThisLine.map((i) => i.x + i.w));
                    const gy2 = Math.max(...onThisLine.map((i) => i.y + i.h));
                    addBlock("highlight", { x: gx, y: gy, w: gx2 - gx, h: gy2 - gy, hType: highlightFormat.type, color: highlightFormat.color, opacity: highlightFormat.opacity });
                  } else {
                    addBlock("highlight", { x, y, w, h, hType: highlightFormat.type, color: highlightFormat.color, opacity: highlightFormat.opacity });
                  }
                } else {
                  addBlock("highlight", { x, y, w, h, hType: highlightFormat.type, color: highlightFormat.color, opacity: highlightFormat.opacity });
                }
              }
            } else if (addingType === "redact") {
              setAddingType(null);
              if (w > 10 && h > 10) {
                addBlock("redact", { x, y, w, h });
              }
            } else if (addingType === "annotate") {
              setAddingType(null);
              if (w > 10 && h > 10) {
                addBlock("comment", { x, y, w, h, text: "Annotation", aType: annoFormat.aType, color: annoFormat.color });
              }
            }
          }}
          style={{ position: "relative", background: "#fff", border: "1px solid #e2e8f0", borderRadius: 8, boxShadow: "0 1px 4px rgba(0,0,0,0.06)", overflow: "hidden", cursor: addingType ? "crosshair" : "default", aspectRatio: "210 / 297", maxWidth: 900, width: "100%" }}>
          {pdfDoc ? (
            <>
              {/* 1. PDF Canvas Layer（可缩放） */}
              <div className="pdf-canvas-layer">
                <canvas ref={canvasRef} style={{ display: "block", width: "100%", height: "auto" }} />
              </div>

              {/* 2. Interaction Layer（不缩放，1:1 px，pointer-events: none） */}
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, transform: "none", pointerEvents: "none" }}>

                {/* TEXT LAYER — 仅显示预览，双击打开 Portal 编辑 */}
                {showTextLayer && textItems.length > 0 && (
                  textItems.map((t) => {
                    const existing = docBlocks.find((b): b is TextBlock => b.type === "text" && Math.abs(b.x - t.x) < 3 && Math.abs(b.y - t.y) < 3);
                    const displayText = existing?.text || t.text;
                    return (
                      <div key={t.id}
                        onClick={() => {
                          if (addingType === "annotate") {
                            const bid = uuid();
                            addBlock("comment", { id: bid, text: t.text, x: t.x, y: t.y, w: t.w, h: t.h, aType: annoFormat.aType, color: annoFormat.color, anchor: { textId: t.id, offset: 0, length: t.text.length } });
                            setAddingType(null);
                          }
                        }}
                        onDoubleClick={() => {
                          if (addingType === "annotate") return;
                          const bid = existing?.id || uuid();
                          setEditingBlock({ id: bid, text: displayText, x: t.x, y: t.y, w: t.w, h: t.h, fontSize: t.fontSize * 0.92 });
                        }}
                        onMouseEnter={(e) => { if (document.activeElement !== e.currentTarget) e.currentTarget.style.background = "rgba(59,130,246,0.08)"; }}
                        onMouseLeave={(e) => { if (document.activeElement !== e.currentTarget) e.currentTarget.style.background = "transparent"; }}
                        onMouseDown={(e) => e.stopPropagation()}
                        style={{
                          position: "absolute",
                          left: t.x,
                          top: t.y,
                          width: "auto",
                          minWidth: t.w,
                          height: t.h,
                          fontSize: t.fontSize * 0.92,
                          lineHeight: 1.3,
                          fontFamily: "'SimSun','Songti SC','Noto Serif CJK SC',serif",
                          outline: "none",
                          border: "none",
                          whiteSpace: "nowrap",
                          overflow: "visible",
                          pointerEvents: "auto",
                          cursor: "text",
                          color: "transparent",
                          background: "transparent",
                          borderRadius: 1,
                          transition: "background 0.15s"
                        }}
                      >
                        {t.text}
                      </div>
                    );
                  })
                )}

                {/* BLOCKS — 文本块双击打开 Portal 编辑，其他类型双击删除 */}
                {pageBlocks.map((b) => (
                  <div key={b.id}
                    onClick={(e) => { e.stopPropagation(); setSelectedBlockId(b.id); }}
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      dragRef.current = { id: b.id, ox: e.clientX, oy: e.clientY, ox0: b.x, oy0: b.y };
                    }}
                    onDoubleClick={(e) => {
                      if (b.type === "text") {
                        e.stopPropagation();
                        setEditingBlock({ id: b.id, text: b.text || "", x: b.x, y: b.y, w: b.w, h: b.h, fontSize: b.fontSize || Math.max(Math.min(b.h * 0.65, b.h - 6), 12) });
                      } else {
                        setBlocks((prev) => prev.filter((x) => x.id !== b.id));
                      }
                    }}
                    style={{ position: "absolute", left: b.x, top: b.y, width: b.w, height: b.h,
                      border: b.type === "highlight" && (b.hType === "underline" || b.hType === "strike" || b.hType === "wavy")
                        ? selectedBlockId === b.id ? "2px solid #8b5cf6" : "1px solid transparent"
                        : b.type === "highlight" ? `2px solid ${b.color || "#facc15"}`
                        : b.type === "redact" ? "2px solid #1e293b"
                        : b.type === "comment" ? "1px dashed #6366f1"
                        : selectedBlockId === b.id ? "2px solid #8b5cf6" : "1px solid #3b82f6",
                      borderRadius: 4,
                      cursor: b.type === "text" ? "grab" : "move",
                      background: b.type === "highlight" && (b.hType === "underline" || b.hType === "strike" || b.hType === "wavy")
                        ? "transparent"
                        : b.type === "highlight" ? "rgba(250,204,21,0.25)"
                        : b.type === "comment" ? "rgba(99,102,241,0.06)"
                        : "rgba(59,130,246,0.04)",
                      display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, overflow: "hidden", pointerEvents: "auto" }}>
                    {b.type === "text" && <span style={{ width: "100%", height: "100%", padding: 0, fontSize: b.fontSize || Math.max(Math.min(b.h * 0.65, b.h - 6), 12), lineHeight: 1.3, fontFamily: b.fontFamily || "'SimSun','Songti SC','Noto Serif CJK SC',serif", background: "#fff", whiteSpace: "nowrap", overflow: "visible", color: b.color || "#000000" }}>{b.text}</span>}
                    {b.type === "image" && b.src && <img src={b.src} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 3 }} />}
                    {b.type === "signature" && b.dataUrl && <img src={b.dataUrl} alt="sig" style={{ width: "100%", height: "100%", objectFit: "contain" }} />}
                    {b.type === "highlight" && (() => {
                      const c = b.color || "#facc15";
                      const a = (b.opacity ?? 40) / 100;
                      const toRGBA = (hex: string, alpha: number) => {
                        const r = parseInt(hex.slice(1, 3), 16);
                        const g = parseInt(hex.slice(3, 5), 16);
                        const bl = parseInt(hex.slice(5, 7), 16);
                        return `rgba(${r},${g},${bl},${alpha})`;
                      };
                      const base = toRGBA(c, a);
                      const line = toRGBA(c, 0.9);
                      switch (b.hType) {
                        case "underline":
                          return <div style={{ width: "100%", height: "100%", position: "relative" }}><div style={{ position: "absolute", bottom: "20%", left: 0, right: 0, height: 2, background: line }} /></div>;
                        case "strike":
                          return <div style={{ width: "100%", height: "100%", position: "relative" }}><div style={{ position: "absolute", top: "50%", left: 0, right: 0, height: 2, background: line }} /></div>;
                        case "wavy":
                          return <div style={{ width: "100%", height: "100%", position: "relative" }}><div style={{ position: "absolute", top: "50%", left: 0, right: 0, height: 6, background: `linear-gradient(45deg, ${line} 25%, transparent 25%, transparent 50%, ${line} 50%, ${line} 75%, transparent 75%, transparent)`, backgroundSize: "8px 8px" }} /></div>;
                        case "freehand":
                        case "text":
                        default:
                          return <div style={{ width: "100%", height: "100%", background: base, borderRadius: 2 }} />;
                      }
                    })()}
                    {b.type === "redact" && <div style={{ width: "100%", height: "100%", background: "#000" }} />}
                    {b.type === "comment" && (() => {
                      const at = b.aType || "note";
                      const cc = b.color || "#3b82f6";
                      const toRGB = (hex: string, a: number) => {
                        const r = parseInt(hex.slice(1, 3), 16);
                        const g = parseInt(hex.slice(3, 5), 16);
                        const bl = parseInt(hex.slice(5, 7), 16);
                        return `rgba(${r},${g},${bl},${a})`;
                      };
                      if (at === "highlight") return <div style={{ width: "100%", height: "100%", background: toRGB(cc, 0.3), borderRadius: 3 }} />;
                      if (at === "strike") return <div style={{ width: "100%", height: "100%", position: "relative" }}><div style={{ position: "absolute", top: "50%", left: 0, right: 0, height: 2, background: cc }} /></div>;
                      if (at === "underline") return <div style={{ width: "100%", height: "100%", position: "relative" }}><div style={{ position: "absolute", bottom: "20%", left: 0, right: 0, height: 2, background: cc }} /></div>;
                      return <div style={{ width: "100%", height: "100%", padding: 6, fontSize: 12, color: cc, overflow: "hidden", display: "flex", alignItems: "flex-start", gap: 4 }}>📌 <span style={{ flex: 1 }}>{b.text}</span></div>;
                    })()}
                    {selectedBlockId === b.id && (
                      <div onMouseDown={(e) => { e.stopPropagation(); e.preventDefault(); resizeRef.current = { id: b.id, startX: e.clientX, startY: e.clientY, initW: b.w, initH: b.h }; }}
                        style={{ position: "absolute", right: -5, bottom: -5, width: 12, height: 12, background: "#8b5cf6", border: "2px solid #fff", borderRadius: 3, cursor: "nwse-resize", pointerEvents: "auto", zIndex: 10 }} />
                    )}
                  </div>
                ))}

                {totalPages > 1 && (
                  <div style={{ position: "absolute", bottom: 12, left: 12, display: "flex", gap: 4, pointerEvents: "auto" }}>
                    <button onClick={() => setPage((p) => Math.max(1, p - 1))} style={{ ...navBtn, opacity: page === 1 ? 0.4 : 1 }}>◀</button>
                    <span style={{ padding: "4px 12px", background: "rgba(0,0,0,0.55)", color: "#fff", borderRadius: 4, fontSize: 12 }}>{page}/{totalPages}</span>
                    <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} style={{ ...navBtn, opacity: page === totalPages ? 0.4 : 1 }}>▶</button>
                  </div>
                )}
              </div>

              {/* 3. Portal root（编辑框脱离 transform） */}
              <div id="edit-portal-root" />
            </>
            ) : (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%", color: "#94a3b8", fontSize: 16, flexDirection: "column", gap: 8 }}>
              <div style={{ fontSize: 40, opacity: 0.3 }}>📄</div><div>Upload a PDF to start editing</div>
            </div>
          )}

          {ocrSelect && (() => {
            const x = Math.min(ocrSelect.startX, ocrSelect.endX);
            const y = Math.min(ocrSelect.startY, ocrSelect.endY);
            const w = Math.abs(ocrSelect.endX - ocrSelect.startX);
            const h = Math.abs(ocrSelect.endY - ocrSelect.startY);
            const mode = addingType === "highlight" ? { border: "#facc15", bg: "rgba(250,204,21,0.12)" } : addingType === "redact" ? { border: "#1e293b", bg: "rgba(30,41,59,0.15)" } : { border: "#8b5cf6", bg: "rgba(139,92,246,0.08)" };
            return <div style={{ position: "absolute", left: x, top: y, width: w, height: h, border: `2px dashed ${mode.border}`, background: mode.bg, pointerEvents: "none", zIndex: 999 }} />;
          })()}
            </div>

            {/* 右侧垂直分页条 */}
            {pdfDoc && totalPages > 1 && (
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, width: 36, flexShrink: 0, padding: "8px 0", alignSelf: "flex-start" }}>
                <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}
                  style={{ width: 28, height: 28, borderRadius: 6, border: "1px solid #e2e8f0", background: page <= 1 ? "#f1f5f9" : "#fff", cursor: page <= 1 ? "not-allowed" : "pointer", fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", padding: 0, opacity: page <= 1 ? 0.4 : 1, color: "#475569" }}>▲</button>
                <span style={{ fontSize: 12, fontWeight: 700, color: "#1e293b", writingMode: "vertical-lr", textOrientation: "mixed", letterSpacing: 4 }}>{page}/{totalPages}</span>
                <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages}
                  style={{ width: 28, height: 28, borderRadius: 6, border: "1px solid #e2e8f0", background: page >= totalPages ? "#f1f5f9" : "#fff", cursor: page >= totalPages ? "not-allowed" : "pointer", fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", padding: 0, opacity: page >= totalPages ? 0.4 : 1, color: "#475569" }}>▼</button>
              </div>
            )}
          </div>
      </div>

      {editingBlock && document.getElementById("edit-portal-root") && createPortal(
        <textarea
          autoFocus
          defaultValue={editingBlock.text}
          onBlur={(e) => {
            const val = e.currentTarget.value;
            setDocBlocks((prev) => {
              const existing = prev.find((b) => b.id === editingBlock.id);
              if (existing) return prev.map((b) => b.id === editingBlock.id ? { ...b, text: val, x: editingBlock.x, y: editingBlock.y, fontSize: editingBlock.fontSize, w: editingBlock.w, h: editingBlock.h } as Block : b);
              return [...prev, { id: editingBlock.id, type: "text", page, x: editingBlock.x, y: editingBlock.y, w: editingBlock.w, h: editingBlock.h, text: val, fontSize: editingBlock.fontSize }];
            });
            setEditingBlock(null);
          }}
          onKeyDown={(e) => {
            if (e.key === "Escape") e.currentTarget.blur();
            if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); e.currentTarget.blur(); }
          }}
          style={{
            position: "absolute",
            left: editingBlock.x - 1,
            top: editingBlock.y - 1,
            width: editingBlock.w,
            height: editingBlock.h,
            fontSize: editingBlock.fontSize,
            lineHeight: 1.3,
            fontFamily: textFormat.fontFamily,
            color: textFormat.color,
            background: "#fff",
            border: "1px solid #3b82f6",
            borderRadius: 4,
            padding: 0,
            boxSizing: "content-box",
            resize: "none",
            overflow: "hidden",
            zIndex: 1000,
          }}
        />,
        document.getElementById("edit-portal-root")!
      )}

      {/* ── 右侧：统一上下文面板 ── */}
      {pdfDoc && (
        <div style={{ width: 240, flexShrink: 0, borderLeft: "1px solid #e2e8f0", padding: 16, background: "#fafafa", fontSize: 12, color: "#475569", maxHeight: "calc(100vh - 80px)", overflowY: "auto" }}>

          {/* 页面控制 */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontWeight: 700, marginBottom: 8, color: "#1e293b", fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5 }}>Page Controls</div>
            <div style={{ display: "flex", gap: 4, alignItems: "center", flexWrap: "wrap" }}>
              <button onClick={handleAddBlankPage} title="Add blank page"
                style={{ width: 28, height: 28, borderRadius: 4, border: "1px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>+</button>
              <button onClick={handleDeletePage} title="Delete this page" disabled={totalPages <= 1}
                style={{ width: 28, height: 28, borderRadius: 4, border: "1px solid #e2e8f0", background: totalPages <= 1 ? "#e2e8f0" : "#fff", cursor: totalPages <= 1 ? "not-allowed" : "pointer", opacity: totalPages <= 1 ? 0.5 : 1, fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>−</button>
              <span style={{ padding: "0 6px", fontWeight: 600, color: "#1e293b", fontSize: 13 }}>{totalPages}</span>
              <span style={{ fontSize: 11, color: "#94a3b8" }}>pages</span>
              <div style={{ width: 1, height: 20, background: "#e2e8f0", margin: "0 4px" }} />
              <button onClick={handleMovePageUp} title="Move page up" disabled={page <= 1}
                style={{ width: 28, height: 28, borderRadius: 4, border: "1px solid #e2e8f0", background: page <= 1 ? "#e2e8f0" : "#fff", cursor: page <= 1 ? "not-allowed" : "pointer", opacity: page <= 1 ? 0.5 : 1, fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>↑</button>
              <button onClick={handleMovePageDown} title="Move page down" disabled={page >= totalPages}
                style={{ width: 28, height: 28, borderRadius: 4, border: "1px solid #e2e8f0", background: page >= totalPages ? "#e2e8f0" : "#fff", cursor: page >= totalPages ? "not-allowed" : "pointer", opacity: page >= totalPages ? 0.5 : 1, fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>↓</button>
            </div>
            <div style={{ marginTop: 6, fontSize: 11, color: "#94a3b8" }}>Page {page} of {totalPages}</div>
          </div>

          {/* ── Workspace Section ── */}
          {workspaceMode && wsAction && (
            <div style={{ marginBottom: 16, padding: "12px", background: "#1a1a2e", borderRadius: 8 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#7c5cfc", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>
                {wsActionsDone.length === 0 ? "Recommended Action" : "Next Step"}
              </div>
              <div style={{ color: "#e0e0e0", fontSize: 14, fontWeight: 600, marginBottom: 4 }}>{wsAction.label}</div>
              <div style={{ color: "#888", fontSize: 11, lineHeight: 1.4, marginBottom: 10 }}>{wsAction.reason}</div>
              <button onClick={() => processInline(wsAction.action)} disabled={processingTool !== null}
                style={{ width: "100%", padding: "10px", border: "none", borderRadius: 6, background: "linear-gradient(135deg,#7c5cfc,#9f7aea)", color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer", opacity: processingTool ? 0.5 : 1 }}>
                Execute
              </button>
            </div>
          )}
          {workspaceMode && wsHints.length > 0 && wsActionsDone.length === 0 && !wsAction && (
            <div style={{ marginBottom: 12, padding: "8px 12px", background: "#0d0d1a", borderRadius: 8, fontSize: 11, color: "#b0b0b0" }}>
              <div style={{ fontWeight: 600, color: "#94a3b8", marginBottom: 4 }}>Detected</div>
              {wsHints.map((h, i) => <div key={i}>• {h.text}</div>)}
            </div>
          )}
          {workspaceMode && wsActionsDone.length > 0 && (
            <div style={{ marginBottom: 12, padding: "8px 12px", background: "#0d0d1a", borderRadius: 8, fontSize: 11 }}>
              <div style={{ color: "#4ade80", fontWeight: 600, marginBottom: 4 }}>✓ Completed ({wsActionsDone.length})</div>
              {wsActionsDone.map((a, i) => <div key={i} style={{ color: "#b0b0b0" }}>✔ {a}</div>)}
            </div>
          )}
          {workspaceMode && wsShowFlow && (
            <div style={{ marginBottom: 16, padding: "12px", background: "rgba(124,92,252,0.08)", borderRadius: 8, border: "1px solid rgba(124,92,252,0.2)" }}>
              <div style={{ color: "#c0b0e0", fontSize: 12, fontWeight: 600, marginBottom: 4 }}>✔ Your document is ready</div>
              <div style={{ color: "#888", fontSize: 11, marginBottom: 10, lineHeight: 1.4 }}>Send directly or download?</div>
              <button onClick={() => { setProcessingTool("flow"); setProcessingLog(["[Flow] Sending via email..."]); setTimeout(() => { setProcessingLog(p => [...p, "[Flow] Paywall required"]); setProcessingTool(null); setShowPayModal(true); }, 1000); }}
                style={{ width: "100%", padding: "8px", border: "none", borderRadius: 6, background: "#7c5cfc", color: "#fff", fontSize: 12, fontWeight: 600, cursor: "pointer", marginBottom: 4 }}>
                📧 Send via Email
              </button>
              <button onClick={() => { handleExport(); }}
                style={{ width: "100%", padding: "8px", border: "1px solid #444", borderRadius: 6, background: "transparent", color: "#ccc", fontSize: 12, cursor: "pointer" }}>
                ⬇️ Download
              </button>
            </div>
          )}

          <div style={{ height: 1, background: "#e2e8f0", margin: "12px 0" }} />

          {/* 活跃工具选项 */}
          <div style={{ marginBottom: 16 }}>
            {!addingType && !selectedBlockId && pdfDoc && !workspaceMode && (
              <div style={{ color: "#94a3b8", fontSize: 11, lineHeight: 1.5 }}>
                Select a tool from the toolbar above, or click on text to edit it. Tool options will appear here.
              </div>
            )}

            {(!addingType || addingType === "text") && pdfDoc && (
              <div>
                <div style={{ fontWeight: 700, marginBottom: 8, color: "#1e293b", fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5 }}>Text Style</div>
                <div style={{ marginBottom: 8 }}>
                  <div style={{ marginBottom: 4, fontSize: 11, color: "#64748b" }}>Font</div>
                  <select value={textFormat.fontFamily} onChange={(e) => { setTextFormat((p) => ({ ...p, fontFamily: e.target.value })); updateSelectedFormat({ fontFamily: e.target.value }); }}
                    style={{ width: "100%", padding: "4px 8px", borderRadius: 4, border: "1px solid #e2e8f0", fontSize: 12 }}>
                    <option value="'SimSun','Songti SC','Noto Serif CJK SC',serif">宋体</option>
                    <option value="sans-serif">Sans-serif</option>
                    <option value="monospace">Monospace</option>
                    <option value="serif">Serif</option>
                    <option value="'KaiTi','STKaiti','Noto Serif CJK SC',serif">楷体</option>
                    <option value="'FangSong','STFangsong',serif">仿宋</option>
                    <option value="'Microsoft YaHei','PingFang SC','Noto Sans CJK SC',sans-serif">微软雅黑</option>
                  </select>
                </div>
                <div style={{ marginBottom: 8 }}>
                  <div style={{ marginBottom: 4, fontSize: 11, color: "#64748b" }}>Size</div>
                  <input type="number" value={textFormat.fontSize}
                    onChange={(e) => { const v = Math.max(8, Math.min(72, Number(e.target.value) || 14)); setTextFormat((p) => ({ ...p, fontSize: v })); updateSelectedFormat({ fontSize: v }); }}
                    style={{ width: "100%", padding: "4px 8px", borderRadius: 4, border: "1px solid #e2e8f0", fontSize: 12 }} min={8} max={72} />
                </div>
                <div>
                  <div style={{ marginBottom: 4, fontSize: 11, color: "#64748b" }}>Color</div>
                  <input type="color" value={textFormat.color}
                    onChange={(e) => { setTextFormat((p) => ({ ...p, color: e.target.value })); updateSelectedFormat({ color: e.target.value }); }}
                    style={{ width: "100%", height: 32, padding: 0, border: "1px solid #e2e8f0", borderRadius: 4, cursor: "pointer" }} />
                </div>
              </div>
            )}

            {addingType === "highlight" && (
              <div>
                <div style={{ fontWeight: 700, marginBottom: 8, color: "#1e293b", fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5 }}>Highlight Options</div>
                <div style={{ marginBottom: 8 }}>
                  <div style={{ marginBottom: 4, fontSize: 11, color: "#64748b" }}>Type</div>
                  <select value={highlightFormat.type} onChange={(e) => setHighlightFormat((p) => ({ ...p, type: e.target.value as any }))}
                    style={{ width: "100%", padding: "4px 8px", borderRadius: 4, border: "1px solid #fde047", fontSize: 12 }}>
                    <option value="text">Text</option>
                    <option value="freehand">Freehand</option>
                    <option value="underline">Underline</option>
                    <option value="strike">Strike</option>
                    <option value="wavy">Wavy</option>
                  </select>
                </div>
                <div style={{ marginBottom: 8 }}>
                  <div style={{ marginBottom: 4, fontSize: 11, color: "#64748b" }}>Color</div>
                  <div style={{ display: "flex", gap: 4 }}>
                    {["#facc15", "#f87171", "#4ade80", "#60a5fa", "#a78bfa"].map((c) => (
                      <button key={c} onClick={() => setHighlightFormat((p) => ({ ...p, color: c }))}
                        style={{ width: 24, height: 24, borderRadius: 12, border: highlightFormat.color === c ? "2px solid #1e293b" : "1px solid #e2e8f0", background: c, cursor: "pointer" }} />
                    ))}
                  </div>
                </div>
                <div>
                  <div style={{ marginBottom: 4, fontSize: 11, color: "#64748b" }}>Opacity ({highlightFormat.opacity}%)</div>
                  <input type="range" min={10} max={100} value={highlightFormat.opacity} onChange={(e) => setHighlightFormat((p) => ({ ...p, opacity: Number(e.target.value) }))} style={{ width: "100%" }} />
                </div>
              </div>
            )}

            {addingType === "annotate" && (
              <div>
                <div style={{ fontWeight: 700, marginBottom: 8, color: "#1e293b", fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5 }}>Annotation Options</div>
                <div style={{ marginBottom: 8 }}>
                  <div style={{ marginBottom: 4, fontSize: 11, color: "#64748b" }}>Type</div>
                  <select value={annoFormat.aType} onChange={(e) => setAnnoFormat((p) => ({ ...p, aType: e.target.value as any }))}
                    style={{ width: "100%", padding: "4px 8px", borderRadius: 4, border: "1px solid #bfdbfe", fontSize: 12 }}>
                    <option value="note">📝 Note</option>
                    <option value="highlight">🟡 Highlight</option>
                    <option value="strike">~~ Strike</option>
                    <option value="underline">_ Underline</option>
                  </select>
                </div>
                <div style={{ marginBottom: 8 }}>
                  <div style={{ marginBottom: 4, fontSize: 11, color: "#64748b" }}>Color</div>
                  <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                    {["#3b82f6", "#facc15", "#f87171", "#4ade80", "#a78bfa", "#1e293b"].map((c) => (
                      <button key={c} onClick={() => setAnnoFormat((p) => ({ ...p, color: c }))}
                        style={{ width: 24, height: 24, borderRadius: 12, border: annoFormat.color === c ? "2px solid #1e293b" : "1px solid #e2e8f0", background: c, cursor: "pointer" }} />
                    ))}
                  </div>
                </div>
                <div style={{ color: "#94a3b8", fontSize: 11 }}>Click on text to annotate</div>
              </div>
            )}

            {addingType === "redact" && (
              <div>
                <div style={{ fontWeight: 700, marginBottom: 8, color: "#1e293b", fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5 }}>Redact Options</div>
                <div style={{ color: "#64748b", fontSize: 11, lineHeight: 1.5 }}>
                  Draw a rectangle over the content you want to permanently redact.
                </div>
              </div>
            )}

            {addingType === "ocr" && (
              <div>
                <div style={{ fontWeight: 700, marginBottom: 8, color: "#1e293b", fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5 }}>OCR Options</div>
                <div style={{ color: "#64748b", fontSize: 11, lineHeight: 1.5 }}>
                  Select a region to run text recognition (OCR) on that area.
                </div>
              </div>
            )}
          </div>

          <div style={{ height: 1, background: "#e2e8f0", margin: "12px 0" }} />

          {/* Blocks 列表 */}
          <div>
            <div style={{ fontWeight: 700, marginBottom: 8, color: "#1e293b", fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span>Blocks ({pageBlocks.length})</span>
              {pageBlocks.length > 0 && <button onClick={() => setBlocks([])} style={{ background: "none", border: "1px solid #fecaca", borderRadius: 4, color: "#ef4444", cursor: "pointer", fontSize: 10, padding: "2px 6px" }}>Clear All</button>}
            </div>
            {pageBlocks.length === 0 && <div style={{ color: "#94a3b8", fontSize: 11 }}>No blocks on this page</div>}
            {pageBlocks.map((b) => (
              <div key={b.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "5px 8px", background: "#f8fafc", borderRadius: 4, marginBottom: 4, fontSize: 11 }}>
                <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1 }}>{b.type}{b.type === "text" && b.text ? `: "${b.text.slice(0, 20)}..."` : ""}</span>
                <button onClick={() => setBlocks((p) => p.filter((x) => x.id !== b.id))} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: 14, padding: 0, lineHeight: 1, marginLeft: 6 }}>×</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {showSignature && (
        <SignaturePad onSave={(dataUrl) => { addBlock("signature", { w: 160, h: 80, dataUrl }); setShowSignature(false); }} onCancel={() => setShowSignature(false)} />
      )}

      {showPayModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999 }}>
          <div style={{ background: "#fff", borderRadius: 12, padding: 28, width: 380, boxShadow: "0 8px 32px rgba(0,0,0,0.2)" }}>
            <h3 style={{ margin: "0 0 8px", fontSize: 18, color: "#1e293b" }}>Free limit reached</h3>
            <p style={{ margin: "0 0 20px", fontSize: 13, color: "#64748b" }}>You've used all 3 free exports today. Pay $1.99 to export this PDF.</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <button onClick={handleStripePay} style={{ padding: "12px 20px", borderRadius: 8, border: "none", background: "#635bff", color: "#fff", cursor: "pointer", fontSize: 14, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                💳 Pay with Card (Stripe)
              </button>
              <button onClick={handlePaypalPay} style={{ padding: "12px 20px", borderRadius: 8, border: "1px solid #e2e8f0", background: "#fff", color: "#1e293b", cursor: "pointer", fontSize: 14, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                <span style={{ color: "#0070ba", fontWeight: 700, fontSize: 16 }}>PayPal</span> Pay with PayPal
              </button>
              <button onClick={() => setShowPayModal(false)} style={{ padding: "8px", borderRadius: 6, border: "none", background: "transparent", color: "#94a3b8", cursor: "pointer", fontSize: 12 }}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Workspace Intent Modal ── */}
      {showIntentModal && (
        <Modal title="What are you trying to do?" onClose={() => setShowIntentModal(false)}>
          <p style={{ fontSize: 12, color: "#64748b", margin: "0 0 16px", lineHeight: 1.5 }}>
            Setting your intent helps us suggest the most relevant next steps for your document.
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {[
              { key: "compress", label: "📦 Compress", desc: "Reduce file size" },
              { key: "edit", label: "✏️ Edit", desc: "Modify document content" },
              { key: "convert", label: "🔄 Convert", desc: "Change document format" },
              { key: "other", label: "📄 Other", desc: "Something else" },
            ].map((opt) => (
              <button key={opt.key} onClick={async () => {
                setShowIntentModal(false);
                const r = await fetch(`${import.meta.env.VITE_API_BASE || ""}/api/workspace/intent`, {
                  method: "POST", headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ doc_id: crypto.randomUUID(), intent: opt.key }),
                }).catch(() => null);
                // Generate local hints/action
                const hints = generateLocalHints(textItems);
                setWsHints(hints);
                if (hints.length > 0) {
                  const h = hints[0];
                  setWsAction({ label: formatActionLabel(h.action), action: h.action, reason: h.text });
                } else {
                  setWsAction({ label: opt.label, action: opt.key, reason: opt.desc });
                }
              }}
                style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", padding: "12px 16px", borderRadius: 8, border: "1px solid #e2e8f0", background: "#f8fafc", cursor: "pointer", fontSize: 13, textAlign: "left" }}>
                <span style={{ fontWeight: 600, color: "#1e293b" }}>{opt.label}</span>
                <span style={{ fontSize: 11, color: "#64748b" }}>{opt.desc}</span>
              </button>
            ))}
          </div>
        </Modal>
      )}

      {/* ── Processing Overlay ── */}
      {processingTool && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999, backdropFilter: "blur(2px)" }}>
          <div style={{ background: "#1a1a2e", borderRadius: 12, padding: 28, width: 460, maxHeight: "70vh", overflow: "hidden", display: "flex", flexDirection: "column" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
              <div style={{ width: 20, height: 20, border: "2px solid #7c5cfc", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.6s linear infinite" }} />
              <span style={{ color: "#e0e0e0", fontSize: 16, fontWeight: 600 }}>Processing: {processingTool}</span>
            </div>
            <div style={{ flex: 1, overflowY: "auto", fontFamily: "monospace", fontSize: 12, color: "#b0b0b0", lineHeight: 1.6 }}>
              {processingLog.map((msg, i) => (
                <div key={i} style={{ color: msg.includes("✅") ? "#4ade80" : msg.includes("❌") ? "#f87171" : msg.includes("⚠") ? "#facc15" : msg.includes("Download") ? "#7c5cfc" : "#b0b0b0" }}>
                  {msg}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Compress Options Modal ── */}
      {showCompressOptions && (
        <Modal title="Compress PDF" onClose={() => setShowCompressOptions(false)}>
          <label style={{ fontSize: 12, color: "#64748b", display: "block", marginBottom: 4 }}>Image Quality: {compressQuality}%</label>
          <input type="range" min={10} max={100} value={compressQuality} onChange={(e) => setCompressQuality(Number(e.target.value))}
            style={{ width: "100%", marginBottom: 12 }} />
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#94a3b8", marginBottom: 16 }}>
            <span>Smaller size</span>
            <span>Better quality</span>
          </div>
          <div style={{ fontSize: 12, color: "#64748b", lineHeight: 1.5, marginBottom: 16, padding: "8px 12px", background: "#f8fafc", borderRadius: 6 }}>
            Lower quality = smaller file size but possible image degradation.
            <br />Recommended: 40–70 for web, 70–90 for print.
          </div>
          <button onClick={() => { setShowCompressOptions(false); processInline("compress", { quality: compressQuality }); }}
            style={{ width: "100%", padding: "12px", border: "none", borderRadius: 8, background: "#7c5cfc", color: "#fff", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
            Compress
          </button>
        </Modal>
      )}

      {/* ── Split Options Modal ── */}
      {showSplitOptions && (
        <Modal title="Split PDF" onClose={() => setShowSplitOptions(false)}>
          <label style={{ fontSize: 12, color: "#64748b", display: "block", marginBottom: 4 }}>Mode</label>
          <select value={splitMode} onChange={(e) => setSplitMode(e.target.value as any)} style={{ width: "100%", padding: "8px 12px", borderRadius: 6, border: "1px solid #e2e8f0", fontSize: 13, marginBottom: 12 }}>
            <option value="all">All pages (one file per page)</option>
            <option value="range">Page range</option>
          </select>
          {splitMode === "range" && (
            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              <div>
                <label style={{ fontSize: 11, color: "#64748b", display: "block", marginBottom: 2 }}>From</label>
                <input type="number" min={1} max={totalPages} value={splitRange[0]} onChange={(e) => setSplitRange([Math.max(1, Number(e.target.value)), splitRange[1]])} style={{ width: 80, padding: "6px 8px", borderRadius: 6, border: "1px solid #e2e8f0", fontSize: 13 }} />
              </div>
              <div>
                <label style={{ fontSize: 11, color: "#64748b", display: "block", marginBottom: 2 }}>To</label>
                <input type="number" min={1} max={totalPages} value={splitRange[1]} onChange={(e) => setSplitRange([splitRange[0], Math.min(totalPages, Number(e.target.value))])} style={{ width: 80, padding: "6px 8px", borderRadius: 6, border: "1px solid #e2e8f0", fontSize: 13 }} />
              </div>
              <div style={{ fontSize: 11, color: "#94a3b8", alignSelf: "flex-end", paddingBottom: 6 }}>{totalPages} pages total</div>
            </div>
          )}
          <button onClick={() => { setShowSplitOptions(false); processInline("split", { mode: splitMode, range: splitMode === "range" ? splitRange : undefined }); }}
            style={{ width: "100%", padding: "12px", border: "none", borderRadius: 8, background: "#7c5cfc", color: "#fff", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
            Split
          </button>
        </Modal>
      )}

      {/* ── Rotate Options Modal ── */}
      {showRotateOptions && (
        <Modal title="Rotate PDF" onClose={() => setShowRotateOptions(false)}>
          <label style={{ fontSize: 12, color: "#64748b", display: "block", marginBottom: 4 }}>Angle</label>
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            {[90, 180, 270].map((d) => (
              <button key={d} onClick={() => setRotateDeg(d as any)}
                style={{ flex: 1, padding: "10px", borderRadius: 6, border: rotateDeg === d ? "2px solid #7c5cfc" : "1px solid #e2e8f0", background: rotateDeg === d ? "#eff6ff" : "#fff", cursor: "pointer", fontSize: 13, fontWeight: rotateDeg === d ? 700 : 500 }}>
                {d}°
              </button>
            ))}
          </div>
          <label style={{ fontSize: 12, color: "#64748b", display: "block", marginBottom: 4 }}>Apply to</label>
          <select value={rotateMode} onChange={(e) => setRotateMode(e.target.value as any)} style={{ width: "100%", padding: "8px 12px", borderRadius: 6, border: "1px solid #e2e8f0", fontSize: 13, marginBottom: 12 }}>
            <option value="all">All pages</option>
            <option value="current">Current page only</option>
          </select>
          <button onClick={() => { setShowRotateOptions(false); processInline("rotate", { degrees: rotateDeg, mode: rotateMode, pageIndex: page - 1 }); }}
            style={{ width: "100%", padding: "12px", border: "none", borderRadius: 8, background: "#7c5cfc", color: "#fff", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
            Rotate
          </button>
        </Modal>
      )}

      {/* ── Page Number Options Modal ── */}
      {showPageNumOptions && (
        <Modal title="Add Page Numbers" onClose={() => setShowPageNumOptions(false)}>
          <label style={{ fontSize: 12, color: "#64748b", display: "block", marginBottom: 4 }}>Position</label>
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            {["top", "bottom"].map((p) => (
              <button key={p} onClick={() => setPageNumOpts((o) => ({ ...o, position: p as any }))}
                style={{ flex: 1, padding: "8px", borderRadius: 6, border: pageNumOpts.position === p ? "2px solid #7c5cfc" : "1px solid #e2e8f0", background: pageNumOpts.position === p ? "#eff6ff" : "#fff", cursor: "pointer", fontSize: 12, fontWeight: pageNumOpts.position === p ? 700 : 500 }}>
                {p === "top" ? "Top" : "Bottom"}
              </button>
            ))}
          </div>
          <label style={{ fontSize: 12, color: "#64748b", display: "block", marginBottom: 4 }}>Alignment</label>
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            {["left", "center", "right"].map((a) => (
              <button key={a} onClick={() => setPageNumOpts((o) => ({ ...o, align: a as any }))}
                style={{ flex: 1, padding: "8px", borderRadius: 6, border: pageNumOpts.align === a ? "2px solid #7c5cfc" : "1px solid #e2e8f0", background: pageNumOpts.align === a ? "#eff6ff" : "#fff", cursor: "pointer", fontSize: 12, fontWeight: pageNumOpts.align === a ? 700 : 500 }}>
                {a.charAt(0).toUpperCase() + a.slice(1)}
              </button>
            ))}
          </div>
          <label style={{ fontSize: 12, color: "#64748b", display: "block", marginBottom: 4 }}>Format</label>
          <input value={pageNumOpts.format} onChange={(e) => setPageNumOpts((o) => ({ ...o, format: e.target.value }))} style={{ width: "100%", padding: "8px 12px", borderRadius: 6, border: "1px solid #e2e8f0", fontSize: 13, marginBottom: 12 }} />
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            <div style={{ flex: 1 }}>
              <label style={{ fontSize: 11, color: "#64748b", display: "block", marginBottom: 2 }}>Start from</label>
              <input type="number" min={1} value={pageNumOpts.startFrom} onChange={(e) => setPageNumOpts((o) => ({ ...o, startFrom: Math.max(1, Number(e.target.value)) }))} style={{ width: "100%", padding: "6px 8px", borderRadius: 6, border: "1px solid #e2e8f0", fontSize: 13 }} />
            </div>
            <div style={{ flex: 1 }}>
              <label style={{ fontSize: 11, color: "#64748b", display: "block", marginBottom: 2 }}>Font size</label>
              <input type="number" min={6} max={72} value={pageNumOpts.fontSize} onChange={(e) => setPageNumOpts((o) => ({ ...o, fontSize: Math.max(6, Number(e.target.value)) }))} style={{ width: "100%", padding: "6px 8px", borderRadius: 6, border: "1px solid #e2e8f0", fontSize: 13 }} />
            </div>
          </div>
          <button onClick={() => { setShowPageNumOptions(false); processInline("pagenum", { opts: pageNumOpts }); }}
            style={{ width: "100%", padding: "12px", border: "none", borderRadius: 8, background: "#7c5cfc", color: "#fff", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
            Add Numbers
          </button>
        </Modal>
      )}

      </div>
    </div>
  );
}

// ── Modal Helper ──
function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9998 }}>
      <div style={{ background: "#fff", borderRadius: 12, padding: 24, width: 420, boxShadow: "0 8px 32px rgba(0,0,0,0.2)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <h3 style={{ margin: 0, fontSize: 16, color: "#1e293b" }}>{title}</h3>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "#94a3b8", cursor: "pointer", fontSize: 18, padding: "0 4px", lineHeight: 1 }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function formatActionLabel(action: string): string {
  const map: Record<string, string> = {
    extract_tables: "Extract Tables", ocr_text: "OCR Text Recognition",
    convert_word: "Convert to Word", compress: "Compress PDF",
    edit: "Edit Document", convert: "Convert Format",
  };
  return map[action] || action.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

const btn: React.CSSProperties = { padding: "7px 12px", background: "#f1f5f9", border: "1px solid #e2e8f0", borderRadius: 6, fontSize: 12, cursor: "pointer", fontWeight: 500, whiteSpace: "nowrap" };
const sep: React.CSSProperties = { width: 1, height: 22, background: "#e2e8f0", margin: "0 2px" };
const navBtn: React.CSSProperties = { padding: "4px 10px", background: "rgba(0,0,0,0.55)", color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", fontSize: 12 };
